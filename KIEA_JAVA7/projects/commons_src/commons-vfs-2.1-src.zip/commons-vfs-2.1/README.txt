To build Commons VFS run

mvn clean install

To build the distribution binaries run

mvn -P apache-release clean install


